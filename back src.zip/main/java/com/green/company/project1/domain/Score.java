package com.green.company.project1.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Score {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sno;

    private int math;
    private int eng;
    private int korea;
    private float total;
    private float avg;
    private String grade;

    public void changeMath(int math) {
        this.math = math;
    }
    public void changeEng(int eng) {
        this.eng = eng;
    }
    public void changeKorea(int korea) {
        this.korea = korea;
    }
    public void changeTotal(float total) {
        this.total = total;
    }
    public void changeAvg(float avg) {
        this.avg = avg;
    }
    public void changeGrade(String grade) {
        this.grade = grade;
    }

}
