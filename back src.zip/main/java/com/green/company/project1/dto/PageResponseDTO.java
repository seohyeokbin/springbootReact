package com.green.company.project1.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Data
public class PageResponseDTO<E> {
    private List<E> dtoList;
    private List<Integer> pageNumList;
    private PageRequestDTO pageRequestDTO; // 현재페이지(page), size(페이지당 size)
    private boolean prev,next;
    private int totalCount, prevPage, nextPage, totalPage, current;


    //생성자 추가 (pdf 35p)
    @Builder(builderMethodName = "withAll")
    public PageResponseDTO(List<E> dtoList, PageRequestDTO pageRequestDTO, long totalCount) {
        this.dtoList = dtoList;
        this.pageRequestDTO = pageRequestDTO;
        this.totalCount=(int)totalCount;

        int end = (int)(Math.ceil(pageRequestDTO.getPage()/10.0))*10;
        int start = end-9;

        int last = (int)(Math.ceil((totalCount/(double)pageRequestDTO.getSize())));
        end = end > last ? last : end;

        this.prev = start > 1;
        this.next = totalCount > end * pageRequestDTO.getSize();

        this.pageNumList = IntStream.rangeClosed(start, end).boxed().collect(Collectors.toList());
        if(prev) this.prevPage=start-1;
        if(next) this.nextPage=end+1;
        this.totalPage=this.pageNumList.size();
        this.current=pageRequestDTO.getPage();
    }

    //prev, next는 이전페이지가 있는가, 다음페이지가 있는가
    //totalCnt(총 데이터수)
    //nextPage(다음 페이지 번호)
    //totalPage(총 페이지 수)

}





//@Data  // Lombok의 @Data 어노테이션으로 getter, setter, toString, equals, hashCode 등을 자동으로 생성
//public class PageResponseDTO<E> {
//    private List<E> dtoList;  // 페이지에 대한 데이터 리스트 (실제 보여줄 데이터)
//    private List<Integer> pageNumList;  // 페이지 번호 리스트 (페이지네이션 버튼에 사용)
//    private PageRequestDTO pageRequestDTO;  // 현재 페이지(page)와 페이지당 사이즈(size)를 담고 있는 요청 정보
//    private boolean prev, next;  // 이전 페이지가 있는지, 다음 페이지가 있는지 여부
//    private int totalCount, prevPage, nextPage, totalPage, current;  // 총 데이터 수, 이전/다음 페이지 번호, 총 페이지 수, 현재 페이지 번호
//
//
//    // 생성자 추가 (pdf 35p)
//    @Builder(builderMethodName = "withAll")  // 빌더 패턴을 사용하여 객체를 생성. builderMethodName 속성으로 "withAll" 메서드를 생성
//    public PageResponseDTO(List<E> dtoList, PageRequestDTO pageRequestDTO, long totalCount) {
//        this.dtoList = dtoList;  // 전달된 dtoList 값 초기화
//        this.pageRequestDTO = pageRequestDTO;  // 전달된 pageRequestDTO 값 초기화
//        this.totalCount = (int) totalCount;  // 전달된 totalCount 값을 정수형으로 변환하여 초기화
//
//        // 페이지 번호 계산을 위한 변수 설정
//        int end = (int) (Math.ceil(pageRequestDTO.getPage() / 10.0)) * 10;  // 현재 페이지 번호를 10 단위로 올림하여 끝 페이지 번호 설정
//        int start = end - 9;  // 시작 페이지 번호는 end에서 9를 뺀 값 (예: end가 20이면 start는 11)
//
//        // 총 페이지 수 계산
//        int last = (int) (Math.ceil((totalCount / (double) pageRequestDTO.getSize())));  // 총 페이지 수 = (총 데이터 수 / 페이지당 사이즈)로 올림 처리
//        end = end > last ? last : end;  // end가 last보다 크면 last로 끝 페이지 설정 (예: 마지막 페이지가 15면 end를 15로 설정)
//
//        // 이전 페이지가 있는지 여부 설정
//        this.prev = start > 1;  // start가 1보다 크면 이전 페이지가 있음
//        this.next = totalCount > end * pageRequestDTO.getSize();  // next는 총 데이터 수가 end 페이지 * 페이지당 사이즈보다 크면 다음 페이지가 있음
//
//        // 페이지 번호 리스트 생성 (start부터 end까지)
//        this.pageNumList = IntStream.rangeClosed(start, end)  // start부터 end까지의 범위에서 숫자 생성
//                .boxed()  // IntStream을 Integer로 박싱
//                .collect(Collectors.toList());  // 리스트로 수집
//
//        // 이전, 다음 페이지 번호 계산
//        if (prev) this.prevPage = start - 1;  // prev가 true이면 이전 페이지 번호는 start-1
//        if (next) this.nextPage = end + 1;  // next가 true이면 다음 페이지 번호는 end+1
//
//        this.totalPage = this.pageNumList.size();  // 총 페이지 수는 pageNumList의 크기
//        this.current = pageRequestDTO.getPage();  // 현재 페이지 번호는 전달된 pageRequestDTO에서 가져옴
//    }
//}