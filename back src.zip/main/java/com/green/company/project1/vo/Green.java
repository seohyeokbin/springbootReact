//package com.green.company.project1.vo;
//
//import lombok.*;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//@ToString
//public class Green {
//    private int price;
//    private int total;
//    private String name;
//    private float vat;
//}
