package com.green.company.project1.service;

import com.green.company.project1.domain.Todo;
import com.green.company.project1.dto.PageRequestDTO;
import com.green.company.project1.dto.PageResponseDTO;
import com.green.company.project1.dto.TodoDTO;
import com.green.company.project1.repository.TodoRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@Transactional //  ACID (원일독지)
@Slf4j
@RequiredArgsConstructor
public class TodoServiceImpl implements TodoService {
//    @Autowired
//    private ModelMapper modelMapper; // 아래와 같은 코드

    private final ModelMapper modelMapper;
    private final TodoRepository todoRepository;


    @Override
    public Long register(TodoDTO todoDTO) {
        log.info("todo service -------------");
        Todo todo = modelMapper.map(todoDTO, Todo.class); //DTO를 Entity로 변환
        Todo savedTodo = todoRepository.save(todo);

        return savedTodo.getTno();
    }


    @Override
    public TodoDTO get(Long tno) {
        log.info("todo service get ------------" + tno);
        Optional<Todo> result = todoRepository.findById(tno);
        Todo todo = result.orElseThrow();
        TodoDTO dto = modelMapper.map(todo, TodoDTO.class);
        return dto;
    }

    @Override
    public List<TodoDTO> findAll() {
        List<Todo> result = todoRepository.findAll();
        List<TodoDTO> resultDtoList = new ArrayList<>();
        result.forEach(i -> {
            TodoDTO data = modelMapper.map(i, TodoDTO.class);
            resultDtoList.add(data);
        });
        return resultDtoList;
    }


    @Override
    public PageResponseDTO<TodoDTO> list(PageRequestDTO pageRequestDTO) {
        // browser url list?page=5 & size=10에 전달되는
        // 값을 controller에 전달하고 그 controller에서 pageRequestDTO 에 정보가 전달된다.
        // pdf 38p
        Pageable pageable = PageRequest.of(pageRequestDTO.getPage() - 1,
                pageRequestDTO.getSize(), Sort.by("tno").descending());

        Page<Todo> result = todoRepository.findAll(pageable);

        List<TodoDTO> dtoList = result.getContent().stream()
                .map(i -> modelMapper.map(i, TodoDTO.class))
                .collect(Collectors.toList());

        long totalCount = result.getTotalElements();

        PageResponseDTO<TodoDTO> responseDTO = PageResponseDTO.<TodoDTO>withAll()
                .dtoList(dtoList)
                .pageRequestDTO(pageRequestDTO)
                .totalCount(totalCount)
                .build();

        return responseDTO;
    }

    @Override
    public void modify(TodoDTO dto) {   // 수정
        Optional<Todo> result = todoRepository.findById(dto.getTno());
        Todo todo = result.orElseThrow();
        todo.changeTitle(dto.getTitle());
        todo.changeDueDate(dto.getDueDate());
        todo.changeComplete(dto.isComplete()); // 여기서 왜 get이 아니라 is인가?
        todoRepository.save(todo);
    }

    @Override
    public void remove(Long tno) {
        todoRepository.deleteById(tno);
    }

    @Override
    public void removeAll() {
        todoRepository.deleteAll();
    }

    @Override
    public void randomTods() {
        List<Todo> todos = todoRepository.findAll();

        String[] rWriters = {"홍길동", "홍길서", "홍길남", "홍길북"};
        String[] rTitles = {"1", "2", "3", "4"};

        Random random = new Random();

        for (Todo todo : todos) {
            todo.setWriter(rWriters[random.nextInt(rWriters.length)]);
            todo.setTitle(rTitles[random.nextInt(rTitles.length)]);
        }

        todoRepository.saveAll(todos);

    }

    @Override
    public void dummyData(int count) {
        log.info("dummy" + count);

        List<TodoDTO> dummy = new ArrayList<>();

        for (int i = 1; i <= count; i++) {
            TodoDTO todoDTO = TodoDTO.builder()
                    .title("가" + i)
                    .writer("나 " + i)
                    .dueDate(LocalDate.now())
                    .build();

            dummy.add(todoDTO);
        }
        dummy.forEach(this::register);
    }

}