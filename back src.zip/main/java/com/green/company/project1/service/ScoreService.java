package com.green.company.project1.service;

import com.green.company.project1.dto.ScoreDTO;
import java.util.List;

public interface ScoreService {
    Long register(ScoreDTO scoreDTO);
    List<ScoreDTO> findAll();
    void modify(ScoreDTO dto);

}