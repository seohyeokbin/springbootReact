package com.green.company.project1.service;

import com.green.company.project1.domain.Score;
import com.green.company.project1.dto.ScoreDTO;
import com.green.company.project1.repository.ScoreRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@Transactional
@Slf4j
@RequiredArgsConstructor
public class ScoreServiceImpl implements ScoreService {

    private final ModelMapper modelMapper;
    private final ScoreRepository scoreRepository;


    @Override
    public Long register(ScoreDTO scoreDTO) {
        Score score = modelMapper.map(scoreDTO, Score.class);
        Score savedScore = scoreRepository.save(score);

        return savedScore.getSno();
    }


    @Override
    public List<ScoreDTO> findAll() {
        List<Score> result = scoreRepository.findAll();
        List<ScoreDTO> resultDtoList = new ArrayList<>();
        result.forEach(i -> {
            ScoreDTO data = modelMapper.map(i, ScoreDTO.class);
            resultDtoList.add(data);
        });
        return resultDtoList;
    }


    @Override
    public void modify(ScoreDTO dto) {
        Optional<Score> result = scoreRepository.findById(dto.getSno());
        Score score = result.orElseThrow();
        score.changeMath(dto.getMath());
        score.changeEng(dto.getEng());
        score.changeKorea(dto.getKorea());
        score.changeTotal(dto.getTotal());
        score.changeAvg(dto.getAvg());
        score.changeGrade(dto.getGrade());

        scoreRepository.save(score);
    }
}