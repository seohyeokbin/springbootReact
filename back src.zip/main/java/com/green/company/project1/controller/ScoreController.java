package com.green.company.project1.controller;

import com.green.company.project1.dto.ScoreDTO;
import com.green.company.project1.service.ScoreService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/score")
@RequiredArgsConstructor
public class ScoreController {

    private final ScoreService scoreService;

    @GetMapping("/list")
    public ResponseEntity<List<ScoreDTO>> getAllScores() {
        // 전체 데이터를 조회
        List<ScoreDTO> scores = scoreService.findAll();

        return ResponseEntity.ok(scores);
    }

    @PostMapping("/")
    public Map<String, Long> register(@RequestBody ScoreDTO scoreDTO) {
        log.info("controller register :", scoreDTO);
        Long sno = scoreService.register(scoreDTO);
        return Map.of("sno", sno);
    }

    @PutMapping("/{sno}")
    public Map<String, String> modify(
            @PathVariable(name = "sno") Long sno,
            @RequestBody ScoreDTO scoreDTO) {
        scoreDTO.setSno(sno);
        log.info("controller 수정:" + sno + ", dto:" + scoreDTO);
        scoreService.modify(scoreDTO);
        return Map.of("result","성공");
    }


}
