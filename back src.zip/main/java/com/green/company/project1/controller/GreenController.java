//package com.green.company.project1.controller;
//
//import com.green.company.project1.vo.Green;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Slf4j
//@RestController
//@CrossOrigin(origins = "http://localhost:3000")
//@RequestMapping("/green/*")
//public class GreenController {
//
//    @GetMapping("/list")
//    public ResponseEntity<List<Green>> green() {
//        List<Green> greenList = new ArrayList<>();
//        int total = 0;
//        for(int i =0;i<100;i++) {
//            int price = 100 + i*100;
//            total += price;
//            greenList.add(new Green(price, total, "홍길동" + i, 1 + i*0.1f));
//        }
//        return new ResponseEntity<>(greenList, HttpStatus.OK);
//    }
//
//    @GetMapping("/read")
//    public String read(String tno) {
//        log.info(tno);
//        return "성공";
//    }
//
//}
