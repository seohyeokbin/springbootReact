package com.green.company.project1.repository;

import com.green.company.project1.domain.Todo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
@Slf4j
public class TodoRepositoryTests2 {
    @Autowired
    private TodoRepository repository;

    @Test
    public void testPaging() {
//        Map<String, List<Integer>> map = new HashMap<>();
//        List<Integer> list = new ArrayList<>();
//        for (int i = 0; i < 10; i++) {
//            list.add(i + i);
//        }
//        map.put("data", list);
//
//
//        int pageSize = 3;
//        int totalPage = (list.size() + pageSize - 1) / pageSize;
//
//
//        for (int p = 0; p < totalPage; p++) {
//            System.out.println("페이지" + (p+ 1) + "------");
//
//            int start = p * pageSize;
//            int end = (start + pageSize) > list.size() ? list.size() : (start + pageSize);
//
//            for (int i = start; i < end; i++) {
//                System.out.println(list.get(i));
//            }
//        }

        // map의 data(List/value)를 사용하여 page, 1,2,3.......10

//        Pageable pageable = PageRequest.of(0, 10, Sort.by("tno").descending());
//        Page<Todo> result = repository.findAll(pageable);
//        log.info("result 총 데이터의 갯수:" + result.getTotalElements());
//        result.getContent().forEach(i->log.info("todo: " +i));

        // page 1 =====
        // 10개
        // page 2 =====
        // 10개
    }

    @Test
    public void testOredering() {
        String[] str = {"tno", "writer", "dueDate"};

        for (String arr : str) {
            PageRequest pageable = PageRequest.of(0, 10, Sort.by(arr).descending());
            Page<Todo> result = repository.findAll(pageable);
            log.info("=== 기준: " + arr + " ===");
            result.getContent().forEach(j -> log.info("todo: " + j));
        }
    }
}
