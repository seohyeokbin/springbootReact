package com.green.company.project1.repository;

import com.green.company.project1.domain.Todo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.swing.text.html.Option;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

@SpringBootTest
@Slf4j
public class TodoRepositoryTests {

    @Autowired
    private TodoRepository repository;

    // 단위 테스트(Unit Test)
    @Test
    public void test(){

        for (int i = 0; i < 100; i++) {
//            Todo todo = new Todo();
//            todo.setComplete(true);
//            todo.setDueDate(LocalDate.now());
//            todo.setTitle("오화" + i);
//            todo.setWriter("홍길동" + i);

            Todo todo= Todo.builder()   // 빌드업패턴, 세터대신 사용하기 편하게
                    .complete(true)
                    .dueDate(LocalDate.now())
                    .title("오화" + i)
                    .writer("홍길동"+i)
                    .build();

            repository.save(todo);
            log.info("사랑");
        }
    }


    @Test   // 조회
    public void testRead(){
//        Long tno = 33l;
//        Optional<Todo> result = repository.findById(tno);
//        Todo todo = result.orElseThrow();
//        log.info("find: "+todo);

//        int[] arr = {1,2,3,11,23};
//        //findAllById
//        List<Todo> result = new ArrayList<>();
//        for ( int i : arr ) {
//            Todo v = repository.findById((long) i).get();
//            if(v.getTno()==i) {
//                result.add(v);
//            }
//        }
//        for(Todo i : result) {
//            log.info("" + i);
//        }

        Long[] arr = {1L, 2L, 3l, 11l, 23l};

        List<Todo> list = repository.findAllById(List.of(arr));
        list.forEach(i -> log.info("find2)"+i));


//        List <Long> tno = Arrays.asList(1l,3l,5l,11l,23l);
//        Iterable<Todo> result = repository.findAllById(tno);
//        result.forEach(todo -> log.info("find: " + todo));

    }

    @Test   // 수정
    public void testModify(){
        Long tno = 33l;
        Optional<Todo> result = repository.findById(tno);
        Todo todo = result.orElseThrow();
        todo.changeTitle("수정했어요 제목을");
        todo.changeComplete(true);
        todo.changeDueDate(LocalDate.of(2025,02,11));
        repository.save(todo);
    }

    @Test   // 삭제
    public void testDelete(){
        repository.deleteById(33L);
    }

    @Test
    public void testDeleteAll(){
        repository.deleteAll();
    }

}
